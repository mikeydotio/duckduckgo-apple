(function () {
    "use strict";

    const STORAGE_KEY_WAS_ENABLED_FOR_HOST = "__darkreader__wasEnabledForHost";
    function wasEnabledForHost() {
        try {
            const value = sessionStorage.getItem(
                STORAGE_KEY_WAS_ENABLED_FOR_HOST
            );
            if (value === "true") {
                return true;
            }
            if (value === "false") {
                return false;
            }
        } catch (err) {}
        return null;
    }

    const isWikipedia =
        location.hostname === "wikipedia.org" ||
        location.hostname.endsWith(".wikipedia.org");

    if (
        document.documentElement instanceof HTMLHtmlElement &&
        matchMedia("(prefers-color-scheme: dark)").matches &&
        wasEnabledForHost() !== false &&
        !document.documentElement.matches(
            ".skin-theme-clientpref-night, .skin-theme-clientpref-os"
        ) &&
        !document.querySelector(".darkreader--fallback") &&
        !document.querySelector(".darkreader") &&
        true
    ) {
        const css = (isWikipedia
            ? [
                  ":root {",
                  "    color-scheme: dark !important;",
                  "    --background-color-base: #101418 !important;",
                  "    --background-color-neutral-subtle: #202122 !important;",
                  "    --background-color-interactive-subtle: #27292d !important;",
                  "    --color-base: #eaecf0 !important;",
                  "    --color-emphasized: #ffffff !important;",
                  "    --color-subtle: #a2a9b1 !important;",
                  "    --color-progressive: #6b9eff !important;",
                  "}",
                  "html, body, #content, .mw-page-container, .mw-body, .mw-body-content,",
                  ".vector-header-container, .vector-sticky-header, .minerva-header, .header-container {",
                  "    background-color: #101418 !important;",
                  "    color: #eaecf0 !important;",
                  "}",
                  "a { color: #6b9eff !important; }",
                  "html, body {",
                  "    opacity: 1 !important;",
                  "    transition: none !important;",
                  "}"
              ]
            : [
                  "html, body, body :not(iframe) {",
                  "    background-color: #181a1b !important;",
                  "    border-color: #776e62 !important;",
                  "    color: #e8e6e3 !important;",
                  "}",
                  "html, body {",
                  "    opacity: 1 !important;",
                  "    transition: none !important;",
                  "}",
                  'div[style*="background-color: rgb(135, 135, 135)"] {',
                  "    background-color: #878787 !important;",
                  "}"
              ]
        ).join("\n");
        const fallback = document.createElement("style");
        fallback.classList.add("darkreader");
        fallback.classList.add("darkreader--fallback");
        fallback.media = "screen";
        fallback.textContent = css;
        if (isWikipedia) {
            const wikipediaThemeObserver = new MutationObserver(() => {
                if (
                    document.documentElement.matches(
                        ".skin-theme-clientpref-night, .skin-theme-clientpref-os"
                    )
                ) {
                    fallback.remove();
                    wikipediaThemeObserver.disconnect();
                }
            });
            wikipediaThemeObserver.observe(document.documentElement, {
                attributes: true,
                attributeFilter: ["class"]
            });
        }
        if (document.head) {
            document.head.append(fallback);
        } else {
            const root = document.documentElement;
            root.append(fallback);
            const observer = new MutationObserver(() => {
                if (document.head) {
                    observer.disconnect();
                    if (fallback.isConnected) {
                        document.head.append(fallback);
                    }
                }
            });
            observer.observe(root, {childList: true});
        }
    }
})();
